﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CookieWeb
{
    public partial class MasterPage: System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}