﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CookieWeb
{
    public partial class MasterPage
    {
        protected global::System.Web.UI.WebControls.ContentPlaceHolder ContentPlaceHolder2;
    }
}